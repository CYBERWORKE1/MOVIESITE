export const RANDOM_TITLES = [
  "Terminator",
  "Avengers",
  "Batman",
  "Matrix",
  "Titanic",
  "Interstellar",
  "The Dark Knight",
];
